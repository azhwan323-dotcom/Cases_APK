[app]
title = Cases
package.name = cases
package.domain = org.cases
source.dir = .
source.include_exts = py,png,jpg,jpeg,kv,atlas,wav,ogg,ttf
version = 1.0
requirements = python3,kivy
orientation = landscape
fullscreen = 1

[buildozer]
log_level = 2
warn_on_root = 1

[buildozer:android]
android.api = 35
android.minapi = 21
android.archs = arm64-v8a, armeabi-v7a
