from kivy.app import App
from kivy.clock import Clock
from kivy.graphics import Color, Rectangle, Ellipse, Line
from kivy.uix.widget import Widget

BLOCK = 50
WORLD_W = 800
GROUND_Y = 600

COLORS = {
    "grass": (0.27, 0.75, 0.27, 1),
    "dirt": (0.51, 0.31, 0.16, 1),
    "stone": (0.43, 0.43, 0.43, 1),
    "wood": (0.59, 0.35, 0.18, 1),
    "leaves": (0.16, 0.63, 0.24, 1),
}


class BlockWorld(Widget):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.world = {}

        self.player_x = 375
        self.player_y = 500

        self.velocity_y = 0
        self.on_ground = False

        self.left = False
        self.right = False
        self.jump = False

        self.selected = "dirt"

        # زمین
        for x in range(0, WORLD_W, BLOCK):
            self.world[(x, GROUND_Y)] = "grass"
            self.world[(x, GROUND_Y + BLOCK)] = "dirt"
            self.world[(x, GROUND_Y + BLOCK * 2)] = "dirt"
            self.world[(x, GROUND_Y + BLOCK * 3)] = "stone"

        # درخت‌ها
        self.make_tree(150)
        self.make_tree(650)

        Clock.schedule_interval(self.update, 1 / 60)

    def make_tree(self, x):

        for y in range(
            GROUND_Y - BLOCK,
            GROUND_Y - BLOCK * 4,
            -BLOCK
        ):
            self.world[(x, y)] = "wood"

        for dx in [-BLOCK, 0, BLOCK]:

            for dy in [
                -BLOCK * 5,
                -BLOCK * 4,
                -BLOCK * 3
            ]:
                self.world[
                    (x + dx, GROUND_Y + dy)
                ] = "leaves"

    # ---------------- لمس ----------------

    def on_touch_down(self, touch):

        x = touch.x

        # دکمه چپ
        if x < 150 and touch.y < 150:
            self.left = True
            return True

        # دکمه راست
        if 150 <= x < 300 and touch.y < 150:
            self.right = True
            return True

        # دکمه پرش
        if x > self.width - 170 and touch.y < 150:

            if self.on_ground:
                self.velocity_y = -18

            self.jump = True
            return True

        # انتخاب بلوک
        if touch.y > self.height - 110:

            index = int(x // 150)

            blocks = [
                "grass",
                "dirt",
                "stone",
                "wood",
                "leaves"
            ]

            if 0 <= index < len(blocks):
                self.selected = blocks[index]
                self.draw()

            return True

        # ساخت / شکستن
        if touch.y > 150:

            # تبدیل مختصات
            wx = int(x // BLOCK) * BLOCK

            wy = int(
                (self.height - touch.y)
                // BLOCK
            ) * BLOCK

            pos = (wx, wy)

            # شکستن
            if pos in self.world: